from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pandas.api.types import is_numeric_dtype, is_datetime64_any_dtype
from IPython.display import display

def clean_table_name(file_name: str) -> str:
    """Clean the table name by removing the file extension and replacing spaces with underscores."""
    return Path(file_name).stem.replace(' ', '_')

def load_gtfs_files(gtfs_folder: str | Path) -> dict[str, pd.DataFrame]:
    """Load GTFS files from the specified folder and return a dictionary of DataFrames."""
    
    data_dir = Path(gtfs_folder)

    if not data_dir.exists():
        raise FileNotFoundError(f"Data folder not found: {data_dir}")

    gtfs_tables = {}

    for file_path in data_dir.glob("*.txt"):
        table_name = clean_table_name(file_path.name)

        gtfs_tables[table_name] = pd.read_csv(file_path)

        print(f"Loaded {file_path.name} as gtfs_tables['{table_name}']")

    return gtfs_tables

def profile_dataframe(
    df: pd.DataFrame,
    sample_rows: int = 5,
    top_n_categories: int = 10,
    include_plots: bool = False,
    plot_max_cols: int = 8,
    plot_ncols: int =2
) -> pd.DataFrame:
    """
    Reusable EDA profiler for a pandas DataFrame.

    - Prints shape and shows a sample.
    - Returns a tidy column-wise summary (dtype, nulls, uniques, basic stats).
    - Optionally renders quick plots (hist for numeric, bar for categorical).

    Parameters
    ----------
    df : pandas.DataFrame
        DataFrame to explore.
    sample_rows : int, default 5
        Number of head rows to display.
    top_n_categories : int, default 10
        For categorical/object columns, show top-N levels (in Notes column).
    include_plots : bool, default False
        If True, draw quick histograms/bars.
    plot_max_cols : int, default 8
        Max number of columns to plot per type (to avoid huge grids).

    Returns
    -------
    pandas.DataFrame
        One row per column with computed statistics and notes.
    """
    print(f"Shape: {df.shape[0]:,} rows × {df.shape[1]:,} cols")
    display(df.head(sample_rows))

    rows = []
    num_cols, cat_cols, dt_cols = [], [], []
    for col in df.columns:
        s = df[col]
        info = {
            "Column": col,
            "Type": str(s.dtype),
            "Non-Null": int(s.notna().sum()),
            "Missing": int(s.isna().sum()),
            "Unique": int(s.nunique(dropna=True)),
            "Notes": ""
        }

        # Numeric
        if is_numeric_dtype(s):
            num_cols.append(col)
            info.update({
                "Mean": s.mean(),
                "Std": s.std(),
                "Min": s.min(),
                "P25": s.quantile(0.25),
                "Median": s.median(),
                "P75": s.quantile(0.75),
                "Max": s.max(),
            })

        # Datetime
        elif is_datetime64_any_dtype(s):
            dt_cols.append(col)
            info.update({
                "Earliest": s.min(),
                "Latest": s.max(),
            })

        # Categorical / Object
        else:
            # Treat object as categorical-like for summary
            if pd.api.types.is_object_dtype(s) or isinstance(s.dtype, pd.CategoricalDtype):
                cat_cols.append(col)
                vc = s.astype("string").str.strip().value_counts(dropna=True)
                topK = vc.head(top_n_categories)
                info["Notes"] = (
                    f"Top {min(top_n_categories, len(vc))} levels: "
                    + ", ".join([f"{k} ({v})" for k, v in topK.items()])
                )

        rows.append(info)

    summary = pd.DataFrame(rows)
    # Order columns nicely
    preferred = ["Column","Type","Non-Null","Missing","Unique",
                 "Mean","Std","Min","P25","Median","P75","Max",
                 "Earliest","Latest","Notes"]
    summary = summary[[c for c in preferred if c in summary.columns]]

    display(summary)
    # Optional quick plots
    if include_plots:
        # Numeric histograms
        if num_cols:
            n = min(len(num_cols), plot_max_cols)
            ncols = plot_ncols
            nrows = int(np.ceil(n / ncols))

            fig, axes = plt.subplots(nrows, ncols, figsize=(6 * ncols, 3 * nrows))
            axes = np.atleast_1d(axes).flatten()

            for ax, col in zip(axes, num_cols[:n]):
                ax.hist(df[col].dropna())
                ax.set_title(f"Histogram: {col}")
                ax.set_xlabel(col)
                ax.set_ylabel("Count")

            # Turn off any unused axes
            for ax in axes[n:]:
                ax.axis("off")

            plt.tight_layout()
            plt.show()

        # Categorical bar charts (top-N)
        if cat_cols:
            n = min(len(cat_cols), plot_max_cols)
            ncols = plot_ncols
            nrows = int(np.ceil(n / ncols))

            fig, axes = plt.subplots(nrows, ncols, figsize=(6 * ncols, 3 * nrows))
            axes = np.atleast_1d(axes).flatten()

            for ax, col in zip(axes, cat_cols[:n]):
                vc = df[col].astype("string").str.strip().value_counts().head(top_n_categories)
                vc.plot(kind="bar", ax=ax)
                ax.set_title(f"Top {top_n_categories} Categories: {col}")
                ax.set_xlabel(col)
                ax.set_ylabel("Count")

            for ax in axes[n:]:
                ax.axis("off")

            plt.tight_layout()
            plt.show()

    return summary

def display_exploration_summaries(datasets, include_plots=True):
    """Display EDA summaries for multiple datasets in a dictionary."""
    for name, df in datasets.items():
        print(f"\nData validation for Dataset: {name} ===")
        display(df.head())
        profile_dataframe(df, include_plots=include_plots)
        print(f"=== End of summary for {name} ===\n")
        